/* 
 COMP20007 Design of Algorithms 

 Read in an estimate (upper bound) of terrain heights (2D in row-major
 form), the actual terrain heights, a list of locations to visit in order, and 
 then traverse the actual grid in the order given recording actual heights.

 Write output to input file name with extension .bit.

 Also compute the battery use by the robot and print it to stdout.

 Author: Andrew Turpin (aturpin@unimelb.edu.au)
 Date: May 2014

 Usage: see usage()
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "grid.h"
#include "bitfile.h"
#include "huflocal.h"
#include "bitarray.h"


#define MOVES_PER_BATTERY   25
#define FILE_NAME_LEN        7
#define FORMAT_LEN           4
#define MAX_READING_LEN      4
#define NEW_LINE_CHR_LEN     1

/* below definitions & prototypes attributes to 
Michael Dipperstein (mdipper@alumni.engr.ucsb.edu),minor changes were made*/
typedef struct code_list_t
{
    byte_t codeLen;     /* number of bits used in code (1 - 255) */
    bit_array_t *code;  /* code used for symbol (left justified) */
} code_list_t;

static int MakeCodeList(huffman_node_t *ht, code_list_t *codeList);

/*function below attributes to "zed_0xff" from stackoverflow */
int get_int_len(int value);



/*
** Print usage message
*/
void
usage(char *exeName) { 
    fprintf(stderr,"Usage: %s estimateFileName actualFileName plotterFileName\n",exeName);
}

/*
** Read command line params, call search
*/
int 
main(int argc, char *argv[]) {
	int i,c,len_sum=0,x=0,width,height;
	data_t curr_diff=0,prev_height=0;
	char actual_diff[MAX_READING_LEN+NEW_LINE_CHR_LEN+1];
	huffman_node_t *huffmanTree;
	code_list_t codeList[NUM_CHARS];

    if (argc != 4) {
        usage(argv[0]);
        return(-1);
    }

        // plotter is not really a "grid" but why not use the read routine
        // to save coding!
    grid_t *sonar   = readGrid(strcmp(argv[1],"-")?fopen(argv[1],"r"):stdin, TRUE);
    grid_t *actual  = readGrid(strcmp(argv[2],"-")?fopen(argv[2],"r"):stdin, TRUE);
    grid_t *plotter = readGrid(strcmp(argv[3],"-")?fopen(argv[3],"r"):stdin, FALSE);

    assert(sonar);
    assert(actual);
    assert(plotter);

        // create output file
    char output_file_name[FILE_NAME_LEN+FORMAT_LEN+1];
    sprintf(output_file_name,"%s.bit",argv[2]);
    printf("%s\n\n",output_file_name);
      
	
    /* put all sonar readings to a char array to suit for the input of 
    huffman coding functions*/
    width=(int)plotter->width;
    height=(int)plotter->height;
    
    char sonar_diff[width*height*(MAX_READING_LEN+NEW_LINE_CHR_LEN)+1];
    
    
    /* store the difference between current and previous reading as the value
    original value is stored for the initial square to visit */
    for (i=0;i<(int)(plotter->width * plotter->height);i++) {
    	    curr_diff=sonar->data[plotter->data[i]];
    	    sprintf(sonar_diff+len_sum,"%d\n",(int)curr_diff);
    	    len_sum+=get_int_len((int)curr_diff)+NEW_LINE_CHR_LEN;
    	    prev_height=sonar->data[plotter->data[i]];
    }
    *(sonar_diff+len_sum)='\0';
    
    /* build a huffman tree and a codeword list corresponding to it */
    huffmanTree=GenerateTreeFromString(sonar_diff);
    assert(huffmanTree);
    /* initialize code list */
    for (c = 0; c < NUM_CHARS; c++)
    {
        codeList[c].code = NULL;
        codeList[c].codeLen = 0;
    }
    assert(MakeCodeList(huffmanTree, codeList));
    
    	    
    bit_file_t *bitfile = BitFileOpen(output_file_name, BF_WRITE);
    assert(bitfile);

    uint32_t bits_sent=0, moves_made=0;
    data_t current_position = plotter->data[0];
    curr_diff=prev_height=len_sum=0;
    
    for(i = 0 ; i < (int)(plotter->width * plotter->height) ; i++) {
    	    /*printf("TADDA\n");*/
        data_t new_position = plotter->data[i];
        moves_made += gridDistance(plotter, current_position, new_position);
        current_position = new_position;
    /* store the difference between current and previous reading as the value to
    the string, original value is stored for the initial square to visit */
        curr_diff=actual->data[current_position];
        sprintf(actual_diff,"%d\n",curr_diff);
        /*printf("%s",actual_diff);*/
        len_sum=get_int_len((int)curr_diff)+NEW_LINE_CHR_LEN;
        actual_diff[len_sum]='\0';
        for (x=0;x<len_sum;x++) {
        	c = actual_diff[x];
        	BitFilePutBits(bitfile,BitArrayGetBits(codeList[c].code),
        		                              codeList[c].codeLen);
        	bits_sent+=(uint32_t)codeList[c].codeLen;
        }
        prev_height=actual->data[current_position];

    }
    for (c = 0; c < NUM_CHARS; c++)
    {
        if (codeList[c].code != NULL)
        {
            BitArrayDestroy(codeList[c].code);
        }
    }


    /* clean up */
    FreeHuffmanTree(huffmanTree);
    assert(!BitFileClose(bitfile));

    printf("M: %10d B: %10d Bat: %10.1f\n",
        moves_made, bits_sent, 
        (float)moves_made/(float)MOVES_PER_BATTERY + (float)bits_sent);

    return 0;
}

/****************************************************************************/
/* Functions below atrribute to "zed_0xff" from stackoverflow */
int get_int_len (int value){
	int l=1;
	while(value>9){ l++; value/=10; }
	return l;
}
/* Functions below atrribute to 
Michael Dipperstein (mdipper@alumni.engr.ucsb.edu),minor changes were made */
/****************************************************************************
*   Function   : MakeCodeList
*   Description: This function uses a huffman tree to build a list of codes
*                and their length for each encoded symbol.  This simplifies
*                the encoding process.  Instead of traversing a tree to
*                in search of the code for any symbol, the code maybe found
*                by accessing cl[symbol].code.
*   Parameters : ht - pointer to root of huffman tree
*                codeList - code list to populate.
*   Effects    : Code values are filled in for symbols in a code list.
*   Returned   : TRUE for success, FALSE for failure
****************************************************************************/
static int MakeCodeList(huffman_node_t *ht, code_list_t *codeList)
{
    bit_array_t *code;
    byte_t depth = 0;

    if((code = BitArrayCreate(256)) == NULL)
    {
        perror("Unable to allocate bit array");
        return (FALSE);
    }

    BitArrayClearAll(code);

    for(;;)
    {
        /* follow this branch all the way left */
        while (ht->left != NULL)
        {
            BitArrayShiftLeft(code, 1);
            ht = ht->left;
            depth++;
        }

        if (ht->value != COMPOSITE_NODE)
        {
            /* enter results in list */
            codeList[ht->value].codeLen = depth;
            codeList[ht->value].code = BitArrayDuplicate(code);
            if (codeList[ht->value].code == NULL)
            {
                perror("Unable to allocate a bit array");
                BitArrayDestroy(code);
                return (FALSE);
            }

            /* now left justify code */
            BitArrayShiftLeft(codeList[ht->value].code, 256 - depth);
        }

        while (ht->parent != NULL)
        {
            if (ht != ht->parent->right)
            {
                /* try the parent's right */
                BitArraySetBit(code, 255);
                ht = ht->parent->right;
                break;
            }
            else
            {
                /* parent's right tried, go up one level yet */
                depth--;
                BitArrayShiftRight(code, 1);
                ht = ht->parent;
            }
        }

        if (ht->parent == NULL)
        {
            /* we're at the top with nowhere to go */
            break;
        }
    }

    BitArrayDestroy(code);
    return (TRUE);
}
