/* 
 COMP20007 Design of Algorithms 

 Read in an estimate (upper bound) of terrain heights (2D in row-major
 form), a list of locations to visit in order, and the bitfile.
 Output the actual heights to stdout.

 Author: Andrew Turpin (aturpin@unimelb.edu.au)
 Date: April 2014

 Usage: see usage()

*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "grid.h"
#include "bitfile.h"
#include "huflocal.h"
#include "bitarray.h"

#define MOVES_PER_BATTERY   25
#define FILE_NAME_LEN        7
#define FORMAT_LEN           4
#define MAX_READING_LEN      4
#define NEW_LINE_CHR_LEN     1

/* below definitions & prototypes attributes to 
Michael Dipperstein (mdipper@alumni.engr.ucsb.edu),minor changes were made*/
typedef struct code_list_t
{
    byte_t codeLen;     /* number of bits used in code (1 - 255) */
    bit_array_t *code;  /* code used for symbol (left justified) */
} code_list_t;

static int MakeCodeList(huffman_node_t *ht, code_list_t *codeList);

/*function below attributes to "zed_0xff" from stackoverflow */
int get_int_len(int value);
/************************************************************************/

/*
** Print usage message
*/
void
usage(char *exeName) { 
    fprintf(stderr,"Usage: %s sonarFileName plotterFileName bitFileName\n",exeName);
}

/*
** Read command line params, call search
*/
int 
main(int argc, char *argv[]) {
    char height_str[MAX_READING_LEN+NEW_LINE_CHR_LEN+1];
    huffman_node_t *huffmanTree,*currentNode;
    code_list_t codeList[NUM_CHARS];
    int i,c,width,height,curr_diff=0,len_sum=0;

    if (argc != 4) {
        usage(argv[0]);
        return(-1);
    }

    grid_t *sonar   = readGrid(strcmp(argv[1],"-")?fopen(argv[1],"r"):stdin, TRUE);
    grid_t *plotter = readGrid(strcmp(argv[2],"-")?fopen(argv[2],"r"):stdin, FALSE);
    
    width=(int)plotter->width;
    height=(int)plotter->height;
    
    char sonar_diff[width*height*(MAX_READING_LEN+NEW_LINE_CHR_LEN)+1];
    
    
    /* store the difference between current and previous reading as the value
    original value is stored for the initial square to visit */
    for (i=0;i<(int)(plotter->width * plotter->height);i++) {
    	    curr_diff=sonar->data[plotter->data[i]];
    	    sprintf(sonar_diff+len_sum,"%d\n",(int)curr_diff);
    	    len_sum+=get_int_len((int)curr_diff)+NEW_LINE_CHR_LEN;
    }
    *(sonar_diff+len_sum)='\0';
    
    /* build a huffman tree and a codeword list corresponding to it */
    huffmanTree=GenerateTreeFromString(sonar_diff);
    assert(huffmanTree);
    /* initialize code list */
    for (c = 0; c < NUM_CHARS; c++)
    {
        codeList[c].code = NULL;
        codeList[c].codeLen = 0;
    }
    assert(MakeCodeList(huffmanTree, codeList));
    
    

    bit_file_t *bitfile = BitFileOpen(argv[3], BF_READ);

    assert(sonar);
    assert(plotter);
    assert(bitfile);

        // temporary home for terrain heights
    data_t *result = (data_t *)malloc(sizeof(data_t) * plotter->width * plotter->height); 
    assert(result);
    
    currentNode = huffmanTree;
    for(uint32_t pos = 0 ; pos < plotter->width * plotter->height ; pos++) {
        i=0;
    	while (1){
    		/* traverse the tree finding matches for our characters */
    		c = BitFileGetBit(bitfile);
    		if (c != 0){
    			currentNode = currentNode->right;
    		}
    		else{
    			currentNode = currentNode->left;
    		}
    		if (currentNode->value != COMPOSITE_NODE){
    			/* we've found a character */
    			if (currentNode->value=='\n') {
    		        /* the stop point for reading in bits for one height */
    		        currentNode = huffmanTree;
    		        height_str[i]='\0';
    				break;
    			}
    			height_str[i]=currentNode->value;
    			i++;
    			currentNode = huffmanTree;          /* back to top of tree */
    		}
    	}
    	result[plotter->data[pos]]=atoi(height_str);
    }

    assert(!BitFileClose(bitfile));

    printf("%d %d\n", plotter->width, plotter->height);
    for(uint32_t pos = 0 ; pos < plotter->width * plotter->height ; pos++)
        printf("%d\n",result[pos]);

    free(result);

    return 0;
}

void Building_HuffmanTree(grid_t *plotter,grid_t *sonar,
	huffman_node_t *huffmanTree,code_list_t *codeList) {    
    
    /* put all sonar readings to a char array to suit for the input of 
    huffman coding functions*/
    int width,height,i=0,len_sum=0,c=0;
    width=(int)plotter->width;
    height=(int)plotter->height;
    char sonar_diff[width*height*(MAX_READING_LEN+NEW_LINE_CHR_LEN)+1];
    data_t curr_diff=0;
    
    /* store the difference between current and previous reading as the value
    original value is stored for the initial square to visit */
    for (i=0;i<(int)(plotter->width * plotter->height);i++) {
    	    curr_diff=sonar->data[plotter->data[i]];
    	    sprintf(sonar_diff+len_sum,"%d\n",(int)curr_diff);
    	    len_sum+=get_int_len((int)curr_diff)+NEW_LINE_CHR_LEN;
    }
    *(sonar_diff+len_sum)='\0';
    
    /* build a huffman tree and a codeword list corresponding to it */
    huffmanTree=GenerateTreeFromString(sonar_diff);
    assert(huffmanTree);
    /* initialize code list */
    for (c = 0; c < NUM_CHARS; c++)
    {
        codeList[c].code = NULL;
        codeList[c].codeLen = 0;
    }
    assert(MakeCodeList(huffmanTree, codeList));
}

/****************************************************************************/
/* Functions below atrribute to "zed_0xff" from stackoverflow */
int get_int_len (int value){
	int l=1;
	while(value>9){ l++; value/=10; }
	return l;
}
/* Functions below atrribute to 
Michael Dipperstein (mdipper@alumni.engr.ucsb.edu),minor changes were made */
/****************************************************************************
*   Function   : MakeCodeList
*   Description: This function uses a huffman tree to build a list of codes
*                and their length for each encoded symbol.  This simplifies
*                the encoding process.  Instead of traversing a tree to
*                in search of the code for any symbol, the code maybe found
*                by accessing cl[symbol].code.
*   Parameters : ht - pointer to root of huffman tree
*                codeList - code list to populate.
*   Effects    : Code values are filled in for symbols in a code list.
*   Returned   : TRUE for success, FALSE for failure
****************************************************************************/
static int MakeCodeList(huffman_node_t *ht, code_list_t *codeList)
{
    bit_array_t *code;
    byte_t depth = 0;

    if((code = BitArrayCreate(256)) == NULL)
    {
        perror("Unable to allocate bit array");
        return (FALSE);
    }

    BitArrayClearAll(code);

    for(;;)
    {
        /* follow this branch all the way left */
        while (ht->left != NULL)
        {
            BitArrayShiftLeft(code, 1);
            ht = ht->left;
            depth++;
        }

        if (ht->value != COMPOSITE_NODE)
        {
            /* enter results in list */
            codeList[ht->value].codeLen = depth;
            codeList[ht->value].code = BitArrayDuplicate(code);
            if (codeList[ht->value].code == NULL)
            {
                perror("Unable to allocate a bit array");
                BitArrayDestroy(code);
                return (FALSE);
            }

            /* now left justify code */
            BitArrayShiftLeft(codeList[ht->value].code, 256 - depth);
        }

        while (ht->parent != NULL)
        {
            if (ht != ht->parent->right)
            {
                /* try the parent's right */
                BitArraySetBit(code, 255);
                ht = ht->parent->right;
                break;
            }
            else
            {
                /* parent's right tried, go up one level yet */
                depth--;
                BitArrayShiftRight(code, 1);
                ht = ht->parent;
            }
        }

        if (ht->parent == NULL)
        {
            /* we're at the top with nowhere to go */
            break;
        }
    }

    BitArrayDestroy(code);
    return (TRUE);
}
